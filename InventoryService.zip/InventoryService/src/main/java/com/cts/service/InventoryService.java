package com.cts.service;

import java.util.Optional;

import com.cts.entity.InventoryEntity;

public interface InventoryService {
	 public Optional<InventoryEntity> checkAvaliability(int id);

}
