package com.cts.exception;


import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class ExceptionHandlerControllerAdvice {
	
	public ExceptionHandlerControllerAdvice() {
		
	}
	
	@ExceptionHandler(RoomException.class)
	
	public final ResponseEntity<ExceptionResponse>  RoomException( RoomException exception, WebRequest request) {
		ExceptionResponse error=new ExceptionResponse();
		error.setExceptionMessage(exception.getMessage());
		error.setTimestamp(new Date());
		return new ResponseEntity<ExceptionResponse>(error,HttpStatus.NOT_FOUND);
		}
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ExceptionResponse> handleException( Exception exception, WebRequest request) {
		ExceptionResponse error=new ExceptionResponse();
		error.setExceptionMessage(exception.getMessage());
		error.setTimestamp(new Date());
		return new ResponseEntity<ExceptionResponse>(error,HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
