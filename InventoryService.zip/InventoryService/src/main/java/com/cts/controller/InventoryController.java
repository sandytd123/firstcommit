package com.cts.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.modal.InventoryEntity;
import com.cts.service.InventoryServices;

@RestController
public class InventoryController {
	@Autowired
	private InventoryServices inventoryservices;
	
//	@GetMapping(value="/getroom/{roomType}")
//	public List<InventoryEntity> getAllRoom(@PathVariable(value="roomType") String roomType){
//		List<InventoryEntity> allroom=new ArrayList<InventoryEntity>();
//		allroom= inventoryservices.searchRoom(roomType);
//		System.out.println(allroom);
//		return allroom;
//		
//	}
	
	@GetMapping(value="/check/{id}")
	public Optional<InventoryEntity> getavalibility(@PathVariable(value="id") Integer id){
		return inventoryservices.checkAvaliability(id);
		
	}
			

}
