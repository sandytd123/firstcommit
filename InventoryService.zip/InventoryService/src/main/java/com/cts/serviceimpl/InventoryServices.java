package com.cts.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.InventoryEntity;
import com.cts.repository.InventoryRepositary;
import com.cts.service.InventoryService;

@Service
public class InventoryServices implements InventoryService {
	 @Autowired
	private InventoryRepositary inventoryRepositary;
	 
//	 public List<InventoryEntity> searchRoom(String roomType){
//		 List<InventoryEntity> RoomList=new ArrayList<>();
//		  RoomList=inventoryRepositary.findByRoomType(roomType);
//		  return RoomList;
//	 }
	
	 public Optional<InventoryEntity> checkAvaliability(int id) {
		  return inventoryRepositary.findById(id);
	 }
	

}
