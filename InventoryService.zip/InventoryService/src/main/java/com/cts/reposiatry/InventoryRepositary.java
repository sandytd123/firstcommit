package com.cts.reposiatry;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.modal.InventoryEntity;

@Repository
public interface InventoryRepositary extends JpaRepository<InventoryEntity, Integer> {

	

	



	





}
