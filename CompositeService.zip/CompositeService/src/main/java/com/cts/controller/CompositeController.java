package com.cts.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.constant.Constant;
import com.cts.modal.AvailableRooms;
import com.cts.modal.InventoryEntity;
import com.cts.modal.PriceDetails;

@RestController
@RequestMapping("/hoteldetail")
public class CompositeController {
	@Autowired
	RestTemplate restTemplate;
	
	public CompositeController() {
		
	}
	
	@GetMapping("/getdetails/{price}/{roomType}")
	public List<AvailableRooms> Roomlist(@PathVariable(value="price") double price,@PathVariable(value="roomType") String roomType){
		ResponseEntity<PriceDetails[]> Showroom=restTemplate.getForEntity(Constant.priceUrl+price+"/"+roomType, PriceDetails[].class);
		PriceDetails[] rooms=Showroom.getBody();
		List<PriceDetails> Allrooms= Arrays.asList(rooms);
		return Allrooms.stream().map(room ->{
			InventoryEntity inventory = restTemplate.getForObject(Constant.inventoryUrl + room.getId(), InventoryEntity.class);
			return new AvailableRooms(room.getId(), inventory.getRoomType(),inventory.isAvailable(), room.getPrice());
		}).collect(Collectors.toList());
	}

}
