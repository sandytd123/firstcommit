package com.cts.modal;



public class InventoryEntity {
    private Integer id;
    private String roomType;
    boolean isAvailable;
    
    public InventoryEntity() {
    	
    }

	public InventoryEntity(Integer id, String roomType, boolean isAvailable) {
		super();
		this.id = id;
		this.roomType = roomType;
		this.isAvailable = isAvailable;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}    
}