package com.hoteldetailsservice.serviceimpl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hoteldetailservice.exception.DataNotFoundException;
import com.hoteldetailsservice.constant.HotelDetailsContants;
import com.hoteldetailsservice.entity.AvailableRooms;
import com.hoteldetailsservice.entity.InventoryEntity;
import com.hoteldetailsservice.entity.PriceDetails;
import com.hoteldetailsservice.service.HotelService;

@Service
public class HotelServiceImpl implements HotelService {
	@Autowired
	RestTemplate restTemplate;
	
	public HotelServiceImpl() {
		
	}

	@Override
	public List<AvailableRooms> Roomlist( double price, String roomType){
		try{
		ResponseEntity<PriceDetails[]> Showroom=restTemplate.getForEntity(HotelDetailsContants.priceUrl+price+"/"+roomType, PriceDetails[].class);
		PriceDetails[] rooms=Showroom.getBody();
		if(rooms.length==0) {
			throw new DataNotFoundException("No rooms are avaliable");
		}
		List<PriceDetails> Allrooms= Arrays.asList(rooms);
		return Allrooms.stream().map(room ->{
			InventoryEntity inventory = restTemplate.getForObject(HotelDetailsContants.inventoryUrl + room.getId(), InventoryEntity.class);
			return new AvailableRooms(room.getId(), inventory.getRoomType(),inventory.isAvailable(), room.getPrice());
		}).collect(Collectors.toList());
		}catch(DataNotFoundException exception) {
			throw new DataNotFoundException("No rooms are avaliable");
		}
	}

}
