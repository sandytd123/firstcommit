package com.hoteldetailsservice.entity;

import lombok.Data;

public @Data class InventoryEntity {
    private Integer id;
    private String roomType;
    boolean isAvailable;
    
    public InventoryEntity() {
    	
    }

	public InventoryEntity(Integer id, String roomType, boolean isAvailable) {
		super();
		this.id = id;
		this.roomType = roomType;
		this.isAvailable = isAvailable;
	}

	
}