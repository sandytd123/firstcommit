package com.hoteldetailsservice.entity;

import lombok.Data;

public @Data class AvailableRooms {
	
	private Integer id;
    private String roomType;
    private Boolean isAvailable;
    private Double price;
    
    public AvailableRooms() {
    	
    }
	public AvailableRooms(Integer id, String roomType, Boolean isAvailable, Double price) {
		super();
		this.id = id;
		this.roomType = roomType;
		this.isAvailable = isAvailable;
		this.price = price;
	}
	
}
