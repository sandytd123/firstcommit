package com.hoteldetailsservice.entity;

import lombok.Data;

public @Data class PriceDetails {
	 private int id;
	 private Double price;
	 private String roomType;
	 
	 public PriceDetails() {
		 
	 }
	
	public PriceDetails(int id, Double price, String roomType) {
		super();
		this.id = id;
		this.price = price;
		this.roomType = roomType;
	}
	

}
