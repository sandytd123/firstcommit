package com.hoteldetailservice.exception;

import lombok.Getter;
import lombok.Setter;


public class ExceptionResponse {
	
	public String exceptionMessage;
 
	public ExceptionResponse() {
		
	}

	public ExceptionResponse(String exceptionMessage) {
		super();
		this.exceptionMessage = exceptionMessage;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}
	
}

