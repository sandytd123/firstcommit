package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.PriceDetails;
import com.cts.service.PriceServices;



@RestController
@CrossOrigin("*")
public class PriceController {
	
	@Autowired
	private PriceServices service;
	@GetMapping(value="getdetail/{price}/{roomType}")
	public List<PriceDetails> getDetails(@PathVariable(value = "price") Double price, @PathVariable(value ="roomType") String room_type){
		return service.searchRoomDetails(price, room_type);
	}
	
}
	
	


