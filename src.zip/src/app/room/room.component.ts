import { Component, OnInit } from '@angular/core';
import { RoomserviceService } from '../roomservice.service';
import{Avaliability} from '../roomdetail';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {
  // price : any;
  // roomtype : any;
  // view:Avaliability[];

  constructor() { }

  ngOnInit(): void {
  //   this.display.showRoom(this.price, this.roomtype).subscribe(all=>{
  //     this.view=all
  //     console.log(all);
  //   });
   }
}
