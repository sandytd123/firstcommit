import { Component, OnInit } from '@angular/core';
import { RoomserviceService } from '../roomservice.service';
import{Avaliability} from '../roomdetail';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {

  view:Avaliability[];

  constructor(private display:RoomserviceService) { }

  ngOnInit(): void {
  }
  detailroom(viewroom:Avaliability){
    this.display.showRoom(viewroom).subscribe(all=>this.view=all);
  }

}
