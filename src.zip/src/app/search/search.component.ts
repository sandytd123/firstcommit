import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoomserviceService } from '../roomservice.service';
import { Avaliability } from '../roomdetail';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  view:Avaliability[];

  constructor(private router:Router,private display:RoomserviceService) { }

  price : any;
  roomType : any;
  ngOnInit(): void {
  }
   onSubmit(){
    this.display.showRoom(this.price, this.roomType).subscribe(all=>{
      this.view=all
    
    });
   }

}
