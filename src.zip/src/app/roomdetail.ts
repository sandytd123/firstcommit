 export class Avaliability{
    id:number;
    roomType:string;
    isAvailable:boolean;
    price:number;

}