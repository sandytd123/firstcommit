 export     class Avaliability{
    id:number;
    roomType:string;
    isAvailable:any;
    price:number;

}