import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Avaliability} from './roomdetail';

@Injectable({
  providedIn: 'root'
})
export class RoomserviceService {

  constructor(private http: HttpClient) { }

  showRoom(price : any, roomType : any ):Observable<any>{
    return this.http.get(`http://localhost:8081/hoteldetail/getdetails/${price}/${roomType}`);
  }

}
