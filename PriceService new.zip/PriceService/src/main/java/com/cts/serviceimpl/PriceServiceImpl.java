package com.cts.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.PriceDetails;
import com.cts.repository.PriceRepository;
import com.cts.service.PriceService;

@Service
public class PriceServiceImpl implements PriceService{
	@Autowired
	private PriceRepository repo;
	
	public List<PriceDetails> searchRoomDetails(Double price, String room_type){
		List<PriceDetails> RoomDetails = new ArrayList<>();
		RoomDetails =repo.findDetails(price, room_type);
		return RoomDetails;
	}

	@Override
	public PriceDetails addroom(PriceDetails room) {
		// TODO Auto-generated method stub
		return  repo.save(room);
	}

	@Override
	public void deleteroombyid(Integer id) {
		
	  repo.deleteById(id);
	}

	@Override
	public PriceDetails updateroom(PriceDetails room) {
		// TODO Auto-generated method stub
		return repo.save(room);
	}

	
	

}
