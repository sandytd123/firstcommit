package com.cts.entity;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class PriceDetails implements Serializable{
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	 private int id;
	@Column(name="room_price")
	 private Double price;
	 private String room_type;
	 
//	 public PriceDetails() {
//		 
//	 }
//	public PriceDetails(int id, Double price, String room_type) {
//		super();
//		this.id = id;
//		this.price = price;
//		this.room_type = room_type;
//	}
	 
	 
	 
	 
	 
	 

}
