package com.hoteldetailsservice.entity;

public class AvailableRooms {
	
	private Integer id;
    private String roomType;
    private Boolean isAvailable;
    private Double price;
	public AvailableRooms(Integer id, String roomType, Boolean isAvailable, Double price) {
		super();
		this.id = id;
		this.roomType = roomType;
		this.isAvailable = isAvailable;
		this.price = price;
	}
	public AvailableRooms() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public Boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(Boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
}
