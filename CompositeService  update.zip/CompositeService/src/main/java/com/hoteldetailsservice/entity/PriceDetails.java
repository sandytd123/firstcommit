package com.hoteldetailsservice.entity;




public class PriceDetails {
	 private int id;
	 private Double price;
	 private String roomType;
	 
	 public PriceDetails() {
		 
	 }
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getroomType() {
		return roomType;
	}
	public void setroomType(String roomType) {
		this.roomType = roomType;
	}
	public PriceDetails(int id, Double price, String roomType) {
		super();
		this.id = id;
		this.price = price;
		this.roomType = roomType;
	}
	

}
