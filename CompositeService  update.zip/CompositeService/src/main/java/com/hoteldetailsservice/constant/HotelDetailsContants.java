package com.hoteldetailsservice.constant;

public class HotelDetailsContants {
	public static final String priceUrl="http://localhost:8085/getdetail/";
	public static final String inventoryUrl="http://localhost:8082/check/";
	

}
