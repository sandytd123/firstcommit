package com.hoteldetailsservice.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hoteldetailsservice.entity.AvailableRooms;
import com.hoteldetailsservice.impl.HotelServiceImpl;

@RestController
@CrossOrigin("*")
@RequestMapping("/hotel")
public class HotelDetailsController {
	@Autowired
    private  HotelServiceImpl hotelImpl;

	 
	
	@GetMapping("/getdetail/{price}/{roomType}")
	public List<AvailableRooms> Roomlist(@PathVariable(value="price") double price,@PathVariable(value="roomType") String roomType){
		return hotelImpl.Roomlist(price, roomType);
		
	}

}
