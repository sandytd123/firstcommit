package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.entity.PriceDetails;

@Repository
public interface PriceRepository extends JpaRepository<PriceDetails, Integer>{
//	List<PriceDetails> findByPrice(Double price);
	@Query(value="SELECT * FROM price_details WHERE price_details.room_price = :price and price_details.room_type= :room_type", nativeQuery = true)
	List<PriceDetails> findDetails(@Param("price") Double price, @Param("room_type") String room_type);
}