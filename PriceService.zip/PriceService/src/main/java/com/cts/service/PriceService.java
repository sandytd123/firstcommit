package com.cts.service;

import java.util.List;

import com.cts.entity.PriceDetails;

public interface PriceService {
	public List<PriceDetails> searchRoomDetails(Double price, String room_type);

}
