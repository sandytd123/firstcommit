package com.cts.service;

import java.util.List;

import com.cts.entity.PriceDetails;

public interface PriceService {
	public List<PriceDetails> searchRoomDetails(Double price, String room_type);
	
	public PriceDetails addroom(PriceDetails room);
	public void deleteroombyid(Integer id);
	public PriceDetails updateroom(PriceDetails room);

}
