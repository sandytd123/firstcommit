package com.cts.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.PriceDetails;
import com.cts.exception.RoomException;
import com.cts.service.PriceService;

import lombok.extern.slf4j.Slf4j;




@RestController
@CrossOrigin("*")
@Slf4j
@RequestMapping("/price")
public class PriceController{
	
	@Autowired
	private PriceService service;
	@GetMapping(value="getdetails/{price}/{room_type}")
	public ResponseEntity<?> getDetails(@PathVariable(value = "price") Double price, @PathVariable(value ="room_type") String room_type){
		log.info("GEt Details:" +price+","+room_type);
		log.debug("Request for getdetails {}",price);
		List<PriceDetails> AllDetails=service.searchRoomDetails(price, room_type);
		if(AllDetails.isEmpty()) {
			log.info("no rooms available");
			throw new RoomException("no rooms r avilable for this price and roomtype");
		}
		return new ResponseEntity<List<PriceDetails>>(AllDetails,HttpStatus.OK);
	}
		
		@PostMapping("/addroom")
		public ResponseEntity<PriceDetails> addRoom(@RequestBody PriceDetails room ){
			PriceDetails  roomadd=service.addroom(room);
			return new ResponseEntity<PriceDetails>(roomadd,HttpStatus.OK);
			}
		@DeleteMapping("/deleteroom/{id}")
		public ResponseEntity<?> deleteroom(@PathVariable("id") Integer id){
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		}
		
		@PutMapping("/update")
		public ResponseEntity<PriceDetails> updateroom(@RequestBody PriceDetails room){
			PriceDetails update=service.updateroom(room);
			return new ResponseEntity<PriceDetails>(update,HttpStatus.OK);
		}
		
		
}


	
	


