package com.cts.repositorytest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PriceRepositoryTest {

	@Test
	void testFindDetails() {
		fail("Not yet implemented");
	}

}
