package com.cts.serviceimpltest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.repository.PriceRepository;
import com.cts.service.PriceService;
import com.cts.serviceimpl.PriceServiceImpl;
import com.cts.PriceServiceApplication;
import com.cts.entity.PriceDetails;
@SpringBootTest(classes = PriceServiceApplication.class)
class PriceServiceImplTest {
	
	
	@InjectMocks
	PriceServiceImpl priceservice;
	
	@Mock
	PriceRepository pricerepository;

	@Test
	void testSearchRoomDetails() {
		List<PriceDetails> priceDetails= new ArrayList<>();
		priceDetails.add(new PriceDetails(1,500.0,"ac"));
		Mockito
		     .when(pricerepository.findDetails(500.0,"ac"))
		     .thenReturn(priceDetails);
		List<PriceDetails> searchRooms= priceservice.searchRoomDetails(500.0,"ac");
		     assertEquals(1,searchRooms.size());
	
	}
	@Test
	public void testNoRoomFound() {
		List<PriceDetails> priceDetails= new ArrayList<>();
		Mockito
		     .when(pricerepository.findDetails(9000.0,"Non-AC"))
		     .thenReturn(priceDetails);
		List<PriceDetails> searchRooms= priceservice.searchRoomDetails(9000.0,"Non-AC");
		     assertEquals(0,searchRooms.size());
	}
	/*
	 * @Test void testAddroom() { fail("Not yet implemented"); }
	 * 
	 * @Test void testDeleteroombyid() { fail("Not yet implemented"); }
	 * 
	 * @Test void testUpdateroom() { fail("Not yet implemented"); }
	 */

}
