package com.cts.service;

import java.util.Optional;

import com.cts.entity.InventoryEntity;

public interface InventoryService {
	 public Optional<InventoryEntity> checkAvaliability(int id);
 public InventoryEntity getroom(Integer id);
 public InventoryEntity addroomInventory(InventoryEntity room);
 public InventoryEntity updateInventory(InventoryEntity updateroom);
}