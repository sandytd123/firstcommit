package com.cts.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.InventoryEntity;
import com.cts.exception.RoomException;
import com.cts.serviceimpl.InventoryServices;
@CrossOrigin("*")
@RestController
public class InventoryController {
	@Autowired
	private InventoryServices inventoryservices;
	
	
//	@GetMapping(value="/check/{id}")
//	public Optional<InventoryEntity> getavalibility(@PathVariable(value="id") int id){
//		return inventoryservices.checkAvaliability(id);
//		
//	}
	@GetMapping(value="/check/{id}")
	public ResponseEntity<?> getavalibility(@PathVariable("id") Integer id){
		Optional<InventoryEntity> check=inventoryservices.checkAvaliability(id);
				if(check.isPresent()){
					return new ResponseEntity<InventoryEntity>(check.get(),HttpStatus.OK);
	}else
		throw new RoomException("no rooma are avaliable with thes id");
				
    }
	
	
	@PutMapping("/updateinventory")
	public ResponseEntity<InventoryEntity> updateroom(@RequestBody InventoryEntity room){
		InventoryEntity update1=inventoryservices.updateInventory(room);
		return new ResponseEntity<InventoryEntity>(update1,HttpStatus.OK);
	}
	
}
