package com.hoteldetailsservice.controllertest;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hoteldetailservice.exception.RoomException;
import com.hoteldetailsservice.CompositeServiceApplication;
import com.hoteldetailsservice.controller.HotelDetailsController;
import com.hoteldetailsservice.entity.AvailableRooms;
import com.hoteldetailsservice.serviceimpl.HotelServiceImpl;
@SpringBootTest(classes = CompositeServiceApplication.class)
public class HotelDetailsControllerTest {
	
	
	@InjectMocks
	HotelDetailsController controller;
	
	
	@Mock
	HotelServiceImpl service;

	
	@Test
	public void testRoomList() {
	List<AvailableRooms> room=Arrays.asList(new AvailableRooms(1, "ac", true, 500.0));
	when(service.Roomlist(500.0, "ac"))
	.thenReturn(room);
	ResponseEntity expectedlist=(ResponseEntity) controller.roomList(500.0, "ac");
	assertEquals(expectedlist.getStatusCode(),HttpStatus.OK);
	
	}
	
	@Test
	public void RoonNotFounf() {
		RoomException exception=assertThrows(RoomException.class, ()->{
			when(service.Roomlist(0.0, "a"))
			.thenThrow(RoomException.class);
			controller.roomList(0.0, "ac");
			
		});
		
		String displaymessage=exception.getMessage();
		String actualmessage="No room are avaliable";
		assertEquals(displaymessage, actualmessage);
	}

	@Test
	public void testGetFallbackRoom() {
		fail("Not yet implemented");
	}

}
