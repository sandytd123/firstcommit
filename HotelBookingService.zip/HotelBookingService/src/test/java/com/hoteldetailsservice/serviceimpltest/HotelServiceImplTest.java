package com.hoteldetailsservice.serviceimpltest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.hoteldetailsservice.serviceimpl.HotelServiceImpl;
import com.hoteldetailservice.exception.RoomException;
import com.hoteldetailsservice.CompositeServiceApplication;
import com.hoteldetailsservice.entity.AvailableRooms;
import com.hoteldetailsservice.entity.InventoryEntity;
import com.hoteldetailsservice.entity.PriceDetails;
import com.hoteldetailsservice.service.HotelService;


@SpringBootTest(classes = CompositeServiceApplication.class)
class HotelServiceImplTest {

	@Mock
	RestTemplate resttemplate;
	
	@InjectMocks
	private HotelServiceImpl hotelImpl;
	
	@Test
	public void serachRoom() {
		List<PriceDetails> roomList=Arrays.asList(new PriceDetails(1, 500.0, "ac"));
	PriceDetails[] roomarray=(PriceDetails[])roomList.toArray();
	InventoryEntity inventory=new InventoryEntity(1, "ac", true);
	Double price = 500.0;
	String roomType = "ac";
	List<AvailableRooms> totalRoom=Arrays.asList(new AvailableRooms(1, "ac", true, 500.0));
	    when(resttemplate.getForEntity("http://PriceService/price/getdetails/"+price+"/"+roomType, PriceDetails[].class))
	    .thenReturn(new ResponseEntity<PriceDetails[]>(roomarray,HttpStatus.OK));
	      when(resttemplate.getForEntity("http://InventoryService/inventory/check/"+1, InventoryEntity.class))
	      .thenReturn(new ResponseEntity<InventoryEntity>(inventory,HttpStatus.OK)); 
	      List<AvailableRooms> expected=hotelImpl.Roomlist(500.0, "ac");
	         assertEquals(expected.get(0).getId(), totalRoom.get(0).getId());
	 }
	
	@Test
	public void RoomNotFound() {
		double price=600.0;
		String roomType="ac";
		Exception exception=assertThrows(RoomException.class, ()-> {
		when(resttemplate.getForEntity("http://PriceService/price/getdetails/"+price+"/" +roomType,PriceDetails[].class))
	    .thenReturn(new ResponseEntity<PriceDetails[]>(HttpStatus.NOT_FOUND));
	      when(resttemplate.getForEntity("http://InventoryService/inventory/check/"+1, InventoryEntity.class))
	      .thenReturn(new ResponseEntity<InventoryEntity>(HttpStatus.NOT_FOUND));
	      hotelImpl.Roomlist(600.0, "ac");
	      });
		
		String displayMessage="No rooms are avaliable with these price and roomtype";
		String actualmessag=exception.getMessage();
		assertEquals(displayMessage, actualmessag);
		
	}

	
}
