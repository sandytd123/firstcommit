package com.hoteldetailsservicetest.service;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

public class HotelServiceTest {

	@Test
	public void testRoomlist() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddroom() {
		fail("Not yet implemented");
	}

}
