package com.hoteldetailsservice.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class InventoryEntity {
    private Integer id;
    private String roomType;
    boolean isAvailable;
    
//    public InventoryEntity() {
//    	
//    }
//
//	public InventoryEntity(Integer id, String roomType, boolean isAvailable) {
//		super();
//		this.id = id;
//		this.roomType = roomType;
//		this.isAvailable = isAvailable;
//	}

	
}