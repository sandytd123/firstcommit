package com.hoteldetailsservice.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class PriceDetails {
	 private int id;
	 private Double price;
	 private String roomType;
	 
//	 public PriceDetails() {
//		 
//	 }
//	
//	public PriceDetails(int id, Double price, String roomType) {
//		super();
//		this.id = id;
//		this.price = price;
//		this.roomType = roomType;
//	}
//	

}
