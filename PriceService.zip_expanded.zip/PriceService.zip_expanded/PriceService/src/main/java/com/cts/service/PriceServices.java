package com.cts.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.PriceDao;
import com.cts.entity.PriceDetails;

@Service
public class PriceServices {
	@Autowired
	private PriceDao dao;
	
	public List<PriceDetails> searchRoomDetails(Double price, String room_type){
		List<PriceDetails> RoomDetails = new ArrayList<>();
		RoomDetails =dao.findDetails(price, room_type);
		return RoomDetails;
	}
	

}
